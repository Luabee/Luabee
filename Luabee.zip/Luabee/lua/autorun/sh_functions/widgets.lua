LUABEE.AddLibrary("widgets", Color(250,250,255))
	LUABEE.CatalogFunction({
	name="wigets.RenderMe",
	args = {},-- %%%Bobble
	returns = {},-- %%%Bobble
	realm = "Shared",
	desc=[[]]-- %%%Bobble
},"widgets",_,_)
LUABEE.CatalogFunction({
	name="wigets.PlayerTick",
	args = {},-- %%%Bobble
	returns = {},-- %%%Bobble
	realm = "Shared",
	desc=[[]]-- %%%Bobble
},"widgets",_,_)